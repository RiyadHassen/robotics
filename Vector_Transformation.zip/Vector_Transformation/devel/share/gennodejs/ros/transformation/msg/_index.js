
"use strict";

let Input = require('./Input.js');
let Output = require('./Output.js');

module.exports = {
  Input: Input,
  Output: Output,
};
