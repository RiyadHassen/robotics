#include <functional>
#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/common/common.hh>
#include <ignition/math/Vector3.hh>
#include <iostream>

namespace gazebo
{
  class Modelpush  : public ModelPlugin
  {
    

    public: void Load(physics::ModelPtr _parent, sdf::ElementPtr /*_sdf*/)
            {
              this->model= _parent;
              this->jointController=this->model->GetJointController();
              //this->pid=common::PID(0.1,0.01,0.03);
              this->updateConnection=event::Events::ConnectWorldUpdateBegin(std::bind(&Modelpush::OnUpdate, this));
            }
            public:
              void OnUpdate(){
                float angleDegree=-60;
                float rad=M_PI*angleDegree/180;
                auto joint_name="arm1_arm2_joint";

                std::string name=this->model->GetJoint(joint_name)->GetScopedName();

                // this->jointController->SetPositionPID(name,pid);

                // this->jointController->SetPositionTarget(name, rad);
                this->jointController->Update();
              }
            private: physics::ModelPtr model;   
            private: physics::JointControllerPtr jointController;
            private:event::ConnectionPtr updateConnection;
            private: common::PID pid;  
             
  };
  GZ_REGISTER_MODEL_PLUGIN(Modelpush)
}